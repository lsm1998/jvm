package com.lsm1998.jvm.util;

import com.lsm1998.jvm.clazz.ClassRead;

/**
 * @作者：刘时明
 * @时间：2019/3/15-19:24
 * @说明：
 */
public class ClassReadUtil
{
    public static short read(ClassRead classRead)
    {
        return classRead.bytes[classRead.currentIndex++];
    }

    public static int readU2(ClassRead classRead)
    {
        short[] s=new short[4];
        s[2]=classRead.bytes[classRead.currentIndex++];
        s[3]=classRead.bytes[classRead.currentIndex++];
        return (int)ByteUtil.shortsToLong(s);
    }

    public static long readU4(ClassRead classRead)
    {
        short[] s=new short[4];
        s[0]=classRead.bytes[classRead.currentIndex++];
        s[1]=classRead.bytes[classRead.currentIndex++];
        s[2]=classRead.bytes[classRead.currentIndex++];
        s[3]=classRead.bytes[classRead.currentIndex++];
        return ByteUtil.shortsToLong(s);
    }
}
