package com.lsm1998.jvm.clazz.attribute.entrie;

import com.lsm1998.jvm.clazz.ClassRead;
import com.lsm1998.jvm.util.ClassReadUtil;

/**
 * @作者：刘时明
 * @时间：2019/3/27-16:56
 * @作用：
 */
public class AppendFrame extends Entrie
{
    public short frameType;
    public int offsetDelta;
    public short[] locals;

    public AppendFrame readInfo(ClassRead classRead)
    {
        this.frameType = ClassReadUtil.read(classRead);
        offsetDelta= ClassReadUtil.readU2(classRead);
        locals=new short[frameType-251];
        for (int i = 0; i < locals.length; i++)
        {
            locals[i]=ClassReadUtil.read(classRead);
        }
        return this;
    }
}
