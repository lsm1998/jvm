package com.lsm1998.jvm.clazz.attribute.entrie;

import com.lsm1998.jvm.clazz.ClassRead;
import com.lsm1998.jvm.util.ClassReadUtil;

/**
 * @作者：刘时明
 * @时间：2019/3/27-17:05
 * @作用：
 */
public class StackItemFrame extends Entrie
{
    public short frameType;

    @Override
    public Entrie readInfo(ClassRead classRead)
    {
        this.frameType = ClassReadUtil.read(classRead);

        return super.readInfo(classRead);
    }
}
