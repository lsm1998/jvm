package com.lsm1998.jvm.util;

import java.io.File;
import java.io.FileInputStream;

/**
 * @作者：刘时明
 * @时间：2019/3/15-11:43
 * @作用：
 */
public class FileUtil
{
    // 每次最大读取2K的字节，避免过多的资源开销
    private static final int MAX_READ = 2 * 1024;

    /**
     * 根据路径读取字节数组返回
     * @param path
     * @return
     */
    public static byte[] getBytes(String path)
    {
        File file = new File(path);
        if (file.exists() && file.canRead())
        {
            /**
             * 此处可以使用 ByteArrayInputStream
             */
            try (FileInputStream fis = new FileInputStream(file))
            {
                long len = file.length();
                byte[] bytes;
                if (len < MAX_READ)
                {
                    bytes = new byte[(int) len];
                    fis.read(bytes);
                } else
                {
                    bytes = new byte[(int) len];
                    int start = 0, size = MAX_READ, temp;
                    while ((temp = fis.read(bytes, start, size)) > 0)
                    {
                        start += temp;
                        if (start + size > len)
                        {
                            size = (int) len - start;
                        }
                    }
                }
                return bytes;
            } catch (Exception e)
            {
                e.printStackTrace();
            }
        } else
        {
            System.err.println("路径：" + path + "的文件不存在或者不可读");
        }
        return null;
    }
}
