package com.lsm1998.jvm;

/**
 * @作者：刘时明
 * @时间：2019/3/29-15:43
 * @作用：测试文件
 */
public class Test
{
    public static void main(String[] args)
    {
        int sum1=0;
        int sum2=0;
        for (int i=1;i<=100 ;i++ )
        {
            if((i<<31)==0)
            {
                sum1+=i;
            }else
            {
                sum2+=i;
            }
        }
    }

    public static String get(int a)
    {
        String str=null;
        a+=10;
        return str+a;
    }

    public void run()
    {
        int a=10;
        int b=0;
        int c=a*b;
    }
}
