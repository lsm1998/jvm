package com.lsm1998.jvm.clazz.attribute.entrie;

import com.lsm1998.jvm.clazz.ClassRead;
import com.lsm1998.jvm.util.ClassReadUtil;

/**
 * @作者：刘时明
 * @时间：2019/3/27-16:49
 * @作用：
 */
public class TopVariableInfo extends Entrie
{
    public short tag;

    public TopVariableInfo readInfo(ClassRead classRead)
    {
        this.tag = ClassReadUtil.read(classRead);
        return this;
    }
}
