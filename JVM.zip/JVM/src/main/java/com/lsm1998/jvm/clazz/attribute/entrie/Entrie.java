package com.lsm1998.jvm.clazz.attribute.entrie;

import com.lsm1998.jvm.clazz.ClassRead;
import com.lsm1998.jvm.util.ClassReadUtil;

/**
 * @作者：刘时明
 * @时间：2019/3/27-16:39
 * @作用：
 */
public class Entrie
{
    public short frameType;

    public Entrie readInfo(ClassRead classRead)
    {
        frameType = ClassReadUtil.read(classRead);
        classRead.currentIndex--;
        System.out.println("frameType="+frameType);
        if (frameType == 0)
        {
            return new TopVariableInfo().readInfo(classRead);
        }else if(frameType==1)
        {

        }else if(frameType==2)
        {

        }else if(frameType==3)
        {

        }
        else if(frameType==4)
        {

        }else if(frameType==5)
        {

        }else if(frameType==6)
        {

        }else if(frameType==7)
        {

        }else if(frameType==8)
        {

        }else if(frameType==19)
        {

        }
        else if(frameType>=252)
        {
            return new AppendFrame().readInfo(classRead);
        }
        return null;
    }
}
