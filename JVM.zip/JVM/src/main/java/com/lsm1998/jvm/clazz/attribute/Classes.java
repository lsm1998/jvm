package com.lsm1998.jvm.clazz.attribute;

import com.lsm1998.jvm.clazz.ClassRead;
import com.lsm1998.jvm.util.ClassReadUtil;

/**
 * @作者：刘时明
 * @时间：2019/3/28-15:56
 * @作用：
 */
public class Classes
{
    public int innerClassInfoIndex;
    public int outerClassInfoIndex;
    public int innerNameIndex;
    public int innerClassAccessFlags;

    public void readInfo(ClassRead classRead)
    {
        innerClassInfoIndex= ClassReadUtil.readU2(classRead);
        outerClassInfoIndex= ClassReadUtil.readU2(classRead);
        innerNameIndex= ClassReadUtil.readU2(classRead);
        innerClassAccessFlags= ClassReadUtil.readU2(classRead);
    }
}
