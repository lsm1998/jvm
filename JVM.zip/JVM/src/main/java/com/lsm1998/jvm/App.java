package com.lsm1998.jvm;

import com.lsm1998.jvm.clazz.ClassRead;
import com.lsm1998.jvm.clazz.Methods;
import com.lsm1998.jvm.clazz.attribute.AttributeInfo;
import com.lsm1998.jvm.clazz.attribute.impl.Code;
import com.lsm1998.jvm.clazz.constant.ConstantInfo;
import com.lsm1998.jvm.interpreter.InstructionFactory;
import com.lsm1998.jvm.interpreter.base.ByteCodeReader;
import com.lsm1998.jvm.interpreter.instruction.Instruction;
import com.lsm1998.jvm.runtimedata.privatedata.*;
import com.lsm1998.jvm.runtimedata.privatedata.Thread;
import com.lsm1998.jvm.util.FileUtil;

import java.util.Arrays;

/**
 * @作者：刘时明
 * @时间：2019/3/15-11:41
 * @作用：启动类
 */
public class App
{
    public static void main(String[] args)
    {
        /**
         * 指定Class文件全路径和方法名，暂不考虑重载
         */
        test2("D:\\Test.class","main");
    }

    /**
     * 解析一个Class文件
     * @param classPath Class文件路径
     */
    private static void test1(String classPath)
    {
        // java解析class文件命令：javap -verbose 文件名
        try
        {
            byte[] bytes = FileUtil.getBytes(classPath);
            ClassRead classRead = ClassRead.analysis(bytes);

            System.out.println("解析对象总览:");
            System.out.println(classRead.getClassFile());
            System.out.println("常量池信息：");
            for (int i = 0; i < classRead.getClassFile().getConstantInfos().length; i++)
            {
                System.out.println(classRead.getClassFile().getConstantInfos()[i]);
            }
            System.out.println("属性表信息：");
            for (int i = 0; i < classRead.getClassFile().getAttributesCount(); i++)
            {
                System.out.println(classRead.getClassFile().getAttributes()[i]);
            }
        }catch (Exception e)
        {
            e.printStackTrace();
        }
    }

    /**
     * 执行一个方法
     * @param classPath Class文件路径
     * @param methodName 方法名
     */
    private static void test2(String classPath,String methodName)
    {
        try
        {
            byte[] bytes = FileUtil.getBytes(classPath);
            ClassRead classRead = ClassRead.analysis(bytes);
            Methods[] methods= classRead.getClassFile().getMethods();
            ConstantInfo[] constantInfos=classRead.getClassFile().getConstantInfos();
            for (int i = 0; i < methods.length; i++)
            {
                Methods method=methods[i];
                String temp=constantInfos[method.nameIndex].toString();
                if(methodName.equals(temp))
                {
                    execute(method);
                }
            }
        }catch (Exception e)
        {
            e.printStackTrace();
        }
    }

    public static void execute(Methods methods)
    {
        Code code=null;
        AttributeInfo[] attributeInfos=methods.attributes;
        for (int i = 0; i < attributeInfos.length; i++)
        {
            if(attributeInfos[i] instanceof Code)
            {
                code=(Code)methods.attributes[i];
            }
        }
        if(code==null)
        {
            System.err.println("找不到Code属性");
            return;
        }
        int maxLocals=code.maxLocals;
        int maxStack=code.maxStack;
        short[] codes=code.code;
        // 创建线程
        Thread thread=Thread.newThread();
        // 创建栈帧
        Frame frame=new Frame(thread,maxLocals,maxStack);
        thread.pushFrame(frame);
        System.out.println("指令条数："+codes.length);
        System.out.println("指令总览："+ Arrays.toString(codes));
        while (true)
        {
            int pc=frame.nextPC;
            thread.pc=pc;
            ByteCodeReader reader=new ByteCodeReader();
            reader.reSet(codes,pc);
            short temp= reader.readU1();
            Instruction instruction= InstructionFactory.NewInstruction(temp);
            System.out.println("指令 => 操作码="+temp+" 符号="+instruction);
            if(instruction==null)
            {
                break;
            }
            instruction.fetchOperands(reader);
            frame.nextPC=reader.pc;
            instruction.execute(frame);
        }
        System.out.println("局部变量表信息：");
        System.out.println(Arrays.toString( frame.localVars.slots));
    }
}
